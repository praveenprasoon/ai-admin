# RC Admin

Production-oriented Django reporting platform for executive and Managing Director use.

## Runtime architecture

- **One ECS Fargate web service with two Django tasks** behind an ALB.
- **Amazon SQS FIFO** for manual and scheduled report requests.
- **AWS Lambda** consumes the FIFO queue and generates reports.
- **EventBridge Scheduler** sends scheduled requests to the FIFO queue.
- **RDS PostgreSQL** stores configuration, jobs, normalized updates, and reports.
- **S3** stores generated artifacts.
- No Celery, Redis, ECS worker service, or ECS Beat service.

## Local testing

Only Docker Desktop is required:

```bash
cp .env.example .env
docker compose up --build
```

Open `http://localhost:8000/admin/`. Local containers include PostgreSQL, ElasticMQ (SQS-compatible FIFO), a report consumer, and a small EventBridge Scheduler emulator.

```bash
docker compose exec web python manage.py createsuperuser
docker compose exec web python manage.py seed_demo
```

Manual report generation returns HTTP 202 and creates a `ReportJob`; the local worker processes it asynchronously.

## Production deployment

Build and push the image, then apply `infra/terraform`. Terraform creates two ECS web tasks, FIFO queue + DLQ, Lambda consumer, EventBridge schedule group, RDS, S3, ALB, IAM, Secrets Manager, alarms, and autoscaling.

See `docs/OPERATIONS.md` and `infra/terraform/README.md` before deployment.
