# Production architecture update

- One ECS Fargate web service, desired count 2.
- Removed Celery, Redis, ECS worker, and ECS Beat.
- Added SQS FIFO report queue and FIFO DLQ.
- Added Lambda FIFO consumer with partial batch failure behavior and idempotent job processing.
- Added EventBridge Scheduler synchronization from Django Admin.
- Added local ElasticMQ FIFO queue, worker, and scheduler emulator.
- Added ReportJob audit/status model and asynchronous HTTP 202 report generation.
- Added Terraform for ECS, Lambda, SQS, EventBridge Scheduler, RDS, S3, IAM, alarms, and cost-conscious single NAT gateway.
- Added separate Lambda container image build.
