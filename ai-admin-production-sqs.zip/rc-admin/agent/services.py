from dataclasses import dataclass

from django.conf import settings


@dataclass
class NarrativeInput:
    organization_name: str
    period_label: str
    metrics: dict
    updates: list[dict]
    warnings: list[str]

class BaseNarrativeProvider:
    def generate(self, data: NarrativeInput) -> str:
        raise NotImplementedError

class LocalNarrativeProvider(BaseNarrativeProvider):
    def generate(self, data: NarrativeInput) -> str:
        total = data.metrics.get("total_projects", 0)
        at_risk = data.metrics.get("at_risk", 0)
        off_track = data.metrics.get("off_track", 0)
        warning_text = (
            f" Data-quality warnings were recorded for {len(data.warnings)} source(s)."
            if data.warnings else ""
        )
        return (
            f"For {data.period_label}, {data.organization_name} reported {total} active project "
            f"updates. {at_risk} project(s) are at risk and {off_track} project(s) are off track. "
            "Leadership attention should focus on unresolved dependencies, blockers, and projects "
            f"with declining delivery confidence.{warning_text}"
        )

def get_narrative_provider() -> BaseNarrativeProvider:
    provider = settings.AI_PROVIDER.lower()
    if provider == "local":
        return LocalNarrativeProvider()
    raise ValueError(
        f"Unsupported AI_PROVIDER '{provider}'. Add the provider implementation in agent/services.py."
    )
