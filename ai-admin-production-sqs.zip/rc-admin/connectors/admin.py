from django.contrib import admin

from .models import DataSource


@admin.register(DataSource)
class DataSourceAdmin(admin.ModelAdmin):
    list_display = ("name", "source_type", "organization", "project", "enabled", "last_success_at")
    list_filter = ("source_type", "enabled", "organization")
    search_fields = ("name", "project__name", "project__key")
