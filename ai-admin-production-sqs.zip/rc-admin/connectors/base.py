from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class ConnectorContext:
    organization_id: int
    project_id: int | None
    start_at: datetime
    end_at: datetime
    configuration: dict[str, Any] = field(default_factory=dict)

@dataclass
class ConnectorResult:
    records: list[dict[str, Any]]
    warnings: list[str] = field(default_factory=list)

class BaseConnector(ABC):
    connector_type: str

    @abstractmethod
    def fetch(self, context: ConnectorContext) -> ConnectorResult:
        raise NotImplementedError
