import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
 initial=True
 dependencies=[('core','0001_initial')]
 operations=[migrations.CreateModel(name='DataSource',fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('created_at',models.DateTimeField(auto_now_add=True)),('updated_at',models.DateTimeField(auto_now=True)),('name',models.CharField(max_length=255)),('source_type',models.CharField(choices=[('mock','Mock / Demo'),('jira','Jira'),('align','Jira Align'),('excel','Excel'),('sharepoint','SharePoint'),('workforce','Workforce'),('custom','Custom')],max_length=50)),('enabled',models.BooleanField(default=True)),('configuration',models.JSONField(blank=True,default=dict)),('credential_secret_name',models.CharField(blank=True,max_length=255)),('last_success_at',models.DateTimeField(blank=True,null=True)),('last_error',models.TextField(blank=True)),('organization',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='data_sources',to='core.organization')),('project',models.ForeignKey(blank=True,null=True,on_delete=django.db.models.deletion.CASCADE,related_name='data_sources',to='core.project'))])]
