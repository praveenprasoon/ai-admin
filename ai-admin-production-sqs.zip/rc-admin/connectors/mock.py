from datetime import UTC, datetime

from .base import BaseConnector, ConnectorContext, ConnectorResult
from .registry import registry


@registry.register
class MockConnector(BaseConnector):
    connector_type = "mock"

    def fetch(self, context: ConnectorContext) -> ConnectorResult:
        cfg = context.configuration
        project_key = cfg.get("project_key", f"PRJ-{context.project_id or 'ORG'}")
        return ConnectorResult(
            records=[
                {
                    "external_id": f"{project_key}-101",
                    "project_key": project_key,
                    "title": cfg.get("title", "Demo delivery update"),
                    "status": cfg.get("status", "AT_RISK"),
                    "percent_complete": int(cfg.get("percent_complete", 65)),
                    "summary": cfg.get(
                        "summary",
                        "Core delivery is progressing, with one cross-team dependency requiring attention.",
                    ),
                    "risks": cfg.get("risks", ["Dependency approval may affect the target date."]),
                    "blockers": cfg.get("blockers", []),
                    "updated_at": datetime.now(UTC).isoformat(),
                    "source_url": cfg.get("source_url", ""),
                }
            ],
            warnings=[],
        )
