from django.db import models

from core.models import Organization, Project, TimeStampedModel


class DataSource(TimeStampedModel):
    TYPE_CHOICES = [
        ("mock", "Mock / Demo"),
        ("jira", "Jira"),
        ("align", "Jira Align"),
        ("excel", "Excel"),
        ("sharepoint", "SharePoint"),
        ("workforce", "Workforce"),
        ("custom", "Custom"),
    ]

    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name="data_sources")
    project = models.ForeignKey(Project, on_delete=models.CASCADE, null=True, blank=True, related_name="data_sources")
    name = models.CharField(max_length=255)
    source_type = models.CharField(max_length=50, choices=TYPE_CHOICES)
    enabled = models.BooleanField(default=True)
    configuration = models.JSONField(default=dict, blank=True)
    credential_secret_name = models.CharField(max_length=255, blank=True)
    last_success_at = models.DateTimeField(null=True, blank=True)
    last_error = models.TextField(blank=True)

    def __str__(self):
        return f"{self.name} ({self.source_type})"
