from .base import BaseConnector


class ConnectorRegistry:
    def __init__(self):
        self._connectors: dict[str, type[BaseConnector]] = {}

    def register(self, connector_cls: type[BaseConnector]):
        if not connector_cls.connector_type:
            raise ValueError("Connector must define connector_type")
        self._connectors[connector_cls.connector_type] = connector_cls
        return connector_cls

    def create(self, connector_type: str) -> BaseConnector:
        try:
            return self._connectors[connector_type]()
        except KeyError as exc:
            raise ValueError(f"No connector registered for '{connector_type}'") from exc

    def available(self) -> list[str]:
        return sorted(self._connectors)

registry = ConnectorRegistry()
