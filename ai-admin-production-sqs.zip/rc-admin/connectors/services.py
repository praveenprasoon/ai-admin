from django.utils import timezone

from .base import ConnectorContext
from .models import DataSource
from .registry import registry


def run_data_source(data_source: DataSource, start_at, end_at):
    connector = registry.create(data_source.source_type)
    context = ConnectorContext(
        organization_id=data_source.organization_id,
        project_id=data_source.project_id,
        start_at=start_at,
        end_at=end_at,
        configuration=data_source.configuration,
    )
    try:
        result = connector.fetch(context)
        data_source.last_success_at = timezone.now()
        data_source.last_error = ""
        data_source.save(update_fields=["last_success_at", "last_error", "updated_at"])
        return result
    except Exception as exc:
        data_source.last_error = str(exc)
        data_source.save(update_fields=["last_error", "updated_at"])
        raise
