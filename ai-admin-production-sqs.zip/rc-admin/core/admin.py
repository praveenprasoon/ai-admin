from django.contrib import admin

from .models import Organization, OrganizationMembership, Portfolio, Project


@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "active", "updated_at")
    search_fields = ("name", "slug")

@admin.register(Portfolio)
class PortfolioAdmin(admin.ModelAdmin):
    list_display = ("key", "name", "organization", "updated_at")
    list_filter = ("organization",)
    search_fields = ("key", "name")

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ("key", "name", "portfolio", "owner", "status", "active")
    list_filter = ("status", "active", "portfolio")
    search_fields = ("key", "name", "owner")

admin.site.register(OrganizationMembership)
