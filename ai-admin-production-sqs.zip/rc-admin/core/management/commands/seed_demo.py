from django.core.management.base import BaseCommand

from connectors.models import DataSource
from core.models import Organization, Portfolio, Project
from reports.models import ReportSchedule
from reports.services import generate_weekly_report


class Command(BaseCommand):
    help = "Seed an RC Admin demonstration organization."

    def handle(self, *args, **options):
        org, _ = Organization.objects.get_or_create(
            slug="rc-demo",
            defaults={"name": "RC Demo Organization"},
        )
        portfolio, _ = Portfolio.objects.get_or_create(
            organization=org,
            key="ENT",
            defaults={"name": "Enterprise Transformation"},
        )

        demo_projects = [
            ("PLAT", "Platform Modernization", "AT_RISK", 68),
            ("DATA", "Data Quality Initiative", "ON_TRACK", 82),
            ("CLOUD", "Cloud Migration", "OFF_TRACK", 45),
        ]

        for key, name, status, percent in demo_projects:
            project, _ = Project.objects.get_or_create(
                portfolio=portfolio,
                key=key,
                defaults={"name": name, "owner": "Demo Owner", "status": status},
            )
            DataSource.objects.get_or_create(
                organization=org,
                project=project,
                name=f"{key} Demo Source",
                defaults={
                    "source_type": "mock",
                    "configuration": {
                        "project_key": key,
                        "title": f"{name} weekly update",
                        "status": status,
                        "percent_complete": percent,
                        "summary": f"{name} has completed {percent}% of planned scope for the reporting period.",
                        "risks": ["Cross-team dependency requires active tracking."] if status != "ON_TRACK" else [],
                        "blockers": ["Executive decision pending."] if status == "OFF_TRACK" else [],
                    },
                },
            )

        ReportSchedule.objects.get_or_create(organization=org)
        report = generate_weekly_report(org)
        self.stdout.write(self.style.SUCCESS(f"Seeded demo data and report {report.id}."))
