import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial=True
    dependencies=[migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations=[
      migrations.CreateModel(name='Organization',fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('created_at',models.DateTimeField(auto_now_add=True)),('updated_at',models.DateTimeField(auto_now=True)),('name',models.CharField(max_length=255)),('slug',models.SlugField(unique=True)),('active',models.BooleanField(default=True))]),
      migrations.CreateModel(name='Portfolio',fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('created_at',models.DateTimeField(auto_now_add=True)),('updated_at',models.DateTimeField(auto_now=True)),('name',models.CharField(max_length=255)),('key',models.CharField(max_length=50)),('organization',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='portfolios',to='core.organization'))],options={'unique_together':{('organization','key')}}),
      migrations.CreateModel(name='Project',fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('created_at',models.DateTimeField(auto_now_add=True)),('updated_at',models.DateTimeField(auto_now=True)),('name',models.CharField(max_length=255)),('key',models.CharField(max_length=50)),('owner',models.CharField(blank=True,max_length=255)),('status',models.CharField(choices=[('ON_TRACK','On Track'),('AT_RISK','At Risk'),('OFF_TRACK','Off Track'),('UNKNOWN','Unknown')],default='UNKNOWN',max_length=20)),('sharepoint_url',models.URLField(blank=True)),('active',models.BooleanField(default=True)),('portfolio',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='projects',to='core.portfolio'))],options={'ordering':['portfolio__key','key'],'unique_together':{('portfolio','key')}}),
      migrations.CreateModel(name='OrganizationMembership',fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('created_at',models.DateTimeField(auto_now_add=True)),('updated_at',models.DateTimeField(auto_now=True)),('role',models.CharField(choices=[('ADMIN','Administrator'),('PMO','PMO'),('MANAGER','Manager'),('VIEWER','Viewer')],default='VIEWER',max_length=20)),('organization',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,to='core.organization')),('user',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,to=settings.AUTH_USER_MODEL))],options={'unique_together':{('user','organization')}}),
    ]
