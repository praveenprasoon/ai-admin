from django.conf import settings
from django.db import models


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True

class Organization(TimeStampedModel):
    name = models.CharField(max_length=255)
    slug = models.SlugField(unique=True)
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.name

class Portfolio(TimeStampedModel):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name="portfolios")
    name = models.CharField(max_length=255)
    key = models.CharField(max_length=50)

    class Meta:
        unique_together = ("organization", "key")

    def __str__(self):
        return f"{self.organization.slug}:{self.key}"

class Project(TimeStampedModel):
    STATUS_CHOICES = [
        ("ON_TRACK", "On Track"),
        ("AT_RISK", "At Risk"),
        ("OFF_TRACK", "Off Track"),
        ("UNKNOWN", "Unknown"),
    ]

    portfolio = models.ForeignKey(Portfolio, on_delete=models.CASCADE, related_name="projects")
    name = models.CharField(max_length=255)
    key = models.CharField(max_length=50)
    owner = models.CharField(max_length=255, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="UNKNOWN")
    sharepoint_url = models.URLField(blank=True)
    active = models.BooleanField(default=True)

    class Meta:
        unique_together = ("portfolio", "key")
        ordering = ["portfolio__key", "key"]

    def __str__(self):
        return f"{self.key} - {self.name}"

class OrganizationMembership(TimeStampedModel):
    ROLE_CHOICES = [
        ("ADMIN", "Administrator"),
        ("PMO", "PMO"),
        ("MANAGER", "Manager"),
        ("VIEWER", "Viewer"),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="VIEWER")

    class Meta:
        unique_together = ("user", "organization")
