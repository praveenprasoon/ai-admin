from .models import OrganizationMembership


def accessible_organization_ids(user):
    if not user.is_authenticated:
        return []
    if user.is_superuser:
        return None
    return list(OrganizationMembership.objects.filter(user=user).values_list("organization_id", flat=True))

def can_manage_organization(user, organization_id):
    if user.is_superuser:
        return True
    return OrganizationMembership.objects.filter(user=user, organization_id=organization_id, role__in=["ADMIN", "PMO"]).exists()
