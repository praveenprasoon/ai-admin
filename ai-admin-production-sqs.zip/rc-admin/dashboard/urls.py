from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="dashboard"),
    path("organizations/<int:organization_id>/generate/", views.generate_now, name="generate-now"),
]
