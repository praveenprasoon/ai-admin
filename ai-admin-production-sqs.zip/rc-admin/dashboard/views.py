from django.contrib.auth.decorators import login_required
from django.db import connections
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render

from core.models import Organization
from core.permissions import accessible_organization_ids, can_manage_organization
from reports.models import WeeklyReport
from reports.queueing import create_and_enqueue_job


def health_live(request):
    return JsonResponse({"status": "ok"})

def health_ready(request):
    checks = {"database": False}
    try:
        with connections["default"].cursor() as cursor:
            cursor.execute("SELECT 1")
            checks["database"] = cursor.fetchone()[0] == 1
    except Exception:
        pass
    code = 200 if all(checks.values()) else 503
    return JsonResponse({"status": "ok" if code == 200 else "degraded", "checks": checks}, status=code)

@login_required
def index(request):
    organizations = Organization.objects.filter(active=True).order_by("name")
    ids = accessible_organization_ids(request.user)
    if ids is not None:
        organizations = organizations.filter(id__in=ids)
    organization_id = request.GET.get("organization")
    selected = None
    reports = WeeklyReport.objects.none()
    if organization_id:
        selected = get_object_or_404(organizations, pk=organization_id)
    elif organizations.exists():
        selected = organizations.first()
    if selected:
        reports = WeeklyReport.objects.filter(organization=selected).prefetch_related("project_updates__project")[:12]
    latest = reports.first() if reports else None
    status_filter = request.GET.get("status", "")
    updates = latest.project_updates.all() if latest else []
    if latest and status_filter:
        updates = updates.filter(status=status_filter)
    return render(request, "dashboard/index.html", {"organizations": organizations, "selected": selected, "reports": reports, "latest": latest, "updates": updates, "status_filter": status_filter, "can_generate": bool(selected and can_manage_organization(request.user, selected.id))})

@login_required
def generate_now(request, organization_id):
    organization = get_object_or_404(Organization, pk=organization_id, active=True)
    if not can_manage_organization(request.user, organization.id):
        return JsonResponse({"detail": "Forbidden"}, status=403)
    create_and_enqueue_job(organization, requested_by=request.user)
    return redirect(f"/?organization={organization.id}")
