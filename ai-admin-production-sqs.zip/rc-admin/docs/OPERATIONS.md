# Operations

## Ownership model
RC Admin is intentionally a modular monolith with managed AWS execution. There are no persistent background workers, Redis cluster, or Celery scheduler to patch.

## Production topology
- ECS Fargate service: desired count 2, one task per Availability Zone where capacity permits.
- Lambda: SQS FIFO event source, batch size 1, partial batch failure reporting.
- SQS FIFO: organization-specific message groups; DLQ after three failed receives.
- EventBridge Scheduler: configured from Django Admin; AWS executes schedules.
- RDS PostgreSQL Single-AZ by default for cost control; enable Multi-AZ if the business RTO requires it.

## Schedule administration
Saving a `ReportSchedule` in Django Admin synchronizes it to EventBridge Scheduler. Django remains the configuration source of truth. Local development marks schedules LOCAL and the scheduler container evaluates them.

## Alarms
Act on: DLQ message count > 0, Lambda errors, ALB 5xx, ECS healthy task count below 2, and RDS storage/CPU thresholds.

## Deployment
Run migrations as a one-off ECS task before updating the service. Do not let both web tasks race migrations in production; set `RUN_MIGRATIONS=false` on the service task definition.

## Recovery
Redrive a DLQ message only after correcting the underlying connector or configuration problem. Job processing is idempotent: completed jobs are not regenerated.
