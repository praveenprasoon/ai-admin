# RC Admin: two-week demo plan

## Demo objective

Demonstrate a credible vertical slice for a 300-person organization:

1. Configure projects and data sources in Django admin.
2. Ingest updates through a pluggable connector.
3. Normalize data into a single reporting model.
4. Generate metrics and an AI-assisted executive narrative.
5. Filter and drill into project-level status.
6. Demonstrate a Friday report schedule.
7. Show an AWS deployment path.

## Week 1

### Days 1-2: Foundation
- Confirm personas and demo story
- Establish repository, CI, Docker Compose, database schema
- Configure authentication approach
- Define normalized project-update model

### Days 3-4: Connectors
- Implement Jira connector or approved mock
- Implement Excel/CSV upload path
- Add connector health, warnings, and retries
- Seed representative data for 10-11 projects

### Day 5: Reporting
- Aggregate KPIs
- Generate weekly report record
- Add deterministic narrative and LLM provider boundary
- Validate evidence URLs and missing-data behavior

## Week 2

### Days 6-7: Dashboard
- Portfolio, program, project filters
- Status cards and project table
- Drill-down details
- Data-quality warning panel

### Days 8-9: Agent experience
- Add ask-your-data endpoint
- Restrict supported questions to the normalized model
- Return evidence and generated visual specifications
- Add prompt-injection and authorization boundaries

### Day 10: Demo hardening
- End-to-end tests
- Performance smoke tests
- Backup demo dataset
- Demo script, screenshots, and deployment runbook

## Post-demo roadmap

- Production Jira, Jira Align, SharePoint, Workday/HR, and Excel connectors
- Entra ID SSO and role-based access
- PowerPoint/PDF generation
- Teams and email delivery
- Retrieval over SharePoint documents with citations
- Row-level security and portfolio tenancy
- Audit logging and model observability
- Human approval for externally distributed reports
- AWS WAF, KMS, Secrets Manager, private networking, and DR
