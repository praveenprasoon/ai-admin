# Terraform deployment

This stack provisions one ECS service with two web tasks, an SQS FIFO queue and FIFO DLQ, a Lambda report consumer, EventBridge Scheduler permissions/group, RDS PostgreSQL, S3, ALB, and alarms.

Build two ECR images:

```bash
docker build -t rc-admin-web -f Dockerfile .
docker build -t rc-admin-lambda -f Dockerfile.lambda .
```

Supply their immutable ECR image URIs plus an ACM certificate ARN:

```bash
terraform init
terraform plan \
  -var='web_container_image=ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/rc-admin-web:GIT_SHA' \
  -var='lambda_container_image=ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/rc-admin-lambda:GIT_SHA' \
  -var='certificate_arn=arn:aws:acm:...'
terraform apply
```

The stack deliberately uses one NAT gateway to reduce fixed cost. This is not zone-redundant; choose two NAT gateways if the organization requires AZ-level egress resilience. RDS is Single-AZ by default and can be changed with `db_multi_az=true`.

Run Django migrations as an explicit one-off ECS task before deploying the new web task definition.
