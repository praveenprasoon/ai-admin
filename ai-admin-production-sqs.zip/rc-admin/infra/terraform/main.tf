data "aws_availability_zones" "available" { state = "available" }
data "aws_caller_identity" "current" {}

locals {
  name = "${var.project_name}-${var.environment}"
  tags = { Application = var.project_name
 Environment = var.environment
 ManagedBy = "Terraform" }
  azs  = slice(data.aws_availability_zones.available.names, 0, 2)
}

resource "aws_vpc" "main" {
  cidr_block = "10.40.0.0/16"
  enable_dns_support = true
  enable_dns_hostnames = true
  tags = merge(local.tags, { Name = local.name })
}
resource "aws_internet_gateway" "main" { vpc_id = aws_vpc.main.id
 tags = local.tags }
resource "aws_subnet" "public" {
  count = 2
  vpc_id = aws_vpc.main.id
  availability_zone = local.azs[count.index]
  cidr_block = cidrsubnet(aws_vpc.main.cidr_block, 4, count.index)
  map_public_ip_on_launch = true
  tags = merge(local.tags, { Name = "${local.name}-public-${count.index + 1}" })
}
resource "aws_subnet" "private" {
  count = 2
  vpc_id = aws_vpc.main.id
  availability_zone = local.azs[count.index]
  cidr_block = cidrsubnet(aws_vpc.main.cidr_block, 4, count.index + 2)
  tags = merge(local.tags, { Name = "${local.name}-private-${count.index + 1}" })
}
resource "aws_eip" "nat" { domain = "vpc"
 tags = local.tags }
resource "aws_nat_gateway" "main" {
  allocation_id = aws_eip.nat.id
  subnet_id = aws_subnet.public[0].id
  depends_on = [aws_internet_gateway.main]
  tags = local.tags
}
resource "aws_route_table" "public" { vpc_id = aws_vpc.main.id
 tags = local.tags }
resource "aws_route" "public" { route_table_id = aws_route_table.public.id
 destination_cidr_block = "0.0.0.0/0"
 gateway_id = aws_internet_gateway.main.id }
resource "aws_route_table_association" "public" { count = 2
 subnet_id = aws_subnet.public[count.index].id
 route_table_id = aws_route_table.public.id }
resource "aws_route_table" "private" { vpc_id = aws_vpc.main.id
 tags = local.tags }
resource "aws_route" "private" { route_table_id = aws_route_table.private.id
 destination_cidr_block = "0.0.0.0/0"
 nat_gateway_id = aws_nat_gateway.main.id }
resource "aws_route_table_association" "private" { count = 2
 subnet_id = aws_subnet.private[count.index].id
 route_table_id = aws_route_table.private.id }

resource "aws_security_group" "alb" {
  name = "${local.name}-alb"
  vpc_id = aws_vpc.main.id
  ingress { from_port = 443
 to_port = 443
 protocol = "tcp"
 cidr_blocks = var.allowed_cidrs }
  egress { from_port = 0
 to_port = 0
 protocol = "-1"
 cidr_blocks = ["0.0.0.0/0"] }
  tags = local.tags
}
resource "aws_security_group" "app" {
  name = "${local.name}-app"
  vpc_id = aws_vpc.main.id
  ingress { from_port = 8000
 to_port = 8000
 protocol = "tcp"
 security_groups = [aws_security_group.alb.id] }
  egress { from_port = 0
 to_port = 0
 protocol = "-1"
 cidr_blocks = ["0.0.0.0/0"] }
  tags = local.tags
}
resource "aws_security_group" "lambda" {
  name = "${local.name}-lambda"
  vpc_id = aws_vpc.main.id
  egress { from_port = 0
 to_port = 0
 protocol = "-1"
 cidr_blocks = ["0.0.0.0/0"] }
  tags = local.tags
}
resource "aws_security_group" "db" {
  name = "${local.name}-db"
  vpc_id = aws_vpc.main.id
  ingress { from_port = 5432
 to_port = 5432
 protocol = "tcp"
 security_groups = [aws_security_group.app.id, aws_security_group.lambda.id] }
  tags = local.tags
}

resource "random_password" "django" { length = 50
 special = false }
resource "random_password" "db" { length = 32
 special = false }
resource "aws_db_subnet_group" "main" { name = local.name
 subnet_ids = aws_subnet.private[*].id
 tags = local.tags }
resource "aws_db_instance" "main" {
  identifier = local.name
  engine = "postgres"
  engine_version = "16.4"
  instance_class = var.db_instance_class
  allocated_storage = 30
  max_allocated_storage = 200
  storage_type = "gp3"
  storage_encrypted = true
  db_name = "rcadmin"
  username = "rcadmin"
  password = random_password.db.result
  db_subnet_group_name = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.db.id]
  multi_az = var.db_multi_az
  backup_retention_period = 14
  deletion_protection = true
  skip_final_snapshot = false
  final_snapshot_identifier = "${local.name}-final"
  publicly_accessible = false
  auto_minor_version_upgrade = true
  tags = local.tags
}

resource "aws_s3_bucket" "reports" { bucket_prefix = "${local.name}-reports-"
 tags = local.tags }
resource "aws_s3_bucket_versioning" "reports" { bucket = aws_s3_bucket.reports.id
 versioning_configuration { status = "Enabled" } }
resource "aws_s3_bucket_server_side_encryption_configuration" "reports" { bucket = aws_s3_bucket.reports.id
 rule { apply_server_side_encryption_by_default { sse_algorithm = "AES256" } } }
resource "aws_s3_bucket_public_access_block" "reports" { bucket = aws_s3_bucket.reports.id
 block_public_acls = true
 block_public_policy = true
 ignore_public_acls = true
 restrict_public_buckets = true }

resource "aws_sqs_queue" "dlq" {
  name = "${local.name}-report-jobs-dlq.fifo"
  fifo_queue = true
  content_based_deduplication = true
  message_retention_seconds = 1209600
  sqs_managed_sse_enabled = true
  tags = local.tags
}
resource "aws_sqs_queue" "jobs" {
  name = "${local.name}-report-jobs.fifo"
  fifo_queue = true
  content_based_deduplication = true
  visibility_timeout_seconds = var.lambda_timeout_seconds
  message_retention_seconds = 345600
  receive_wait_time_seconds = 20
  sqs_managed_sse_enabled = true
  redrive_policy = jsonencode({ deadLetterTargetArn = aws_sqs_queue.dlq.arn, maxReceiveCount = 3 })
  tags = local.tags
}

resource "aws_scheduler_schedule_group" "main" { name = local.name
 tags = local.tags }
resource "aws_iam_role" "scheduler" {
  name = "${local.name}-scheduler"
  assume_role_policy = jsonencode({ Version = "2012-10-17", Statement = [{ Effect = "Allow", Principal = { Service = "scheduler.amazonaws.com" }, Action = "sts:AssumeRole" }] })
  tags = local.tags
}
resource "aws_iam_role_policy" "scheduler" {
  role = aws_iam_role.scheduler.id
  policy = jsonencode({ Version = "2012-10-17", Statement = [
    { Effect = "Allow", Action = ["sqs:SendMessage"], Resource = aws_sqs_queue.jobs.arn },
    { Effect = "Allow", Action = ["sqs:SendMessage"], Resource = aws_sqs_queue.dlq.arn }
  ] })
}

resource "aws_secretsmanager_secret" "app" { name = "${local.name}/app"
 tags = local.tags }
resource "aws_secretsmanager_secret_version" "app" {
  secret_id = aws_secretsmanager_secret.app.id
  secret_string = jsonencode({
    DJANGO_SECRET_KEY = random_password.django.result
    DATABASE_URL = "postgresql://rcadmin:${random_password.db.result}@${aws_db_instance.main.address}:5432/rcadmin"
  })
}

resource "aws_cloudwatch_log_group" "ecs" { name = "/ecs/${local.name}"
 retention_in_days = 30
 tags = local.tags }
resource "aws_cloudwatch_log_group" "lambda" { name = "/aws/lambda/${local.name}-report-worker"
 retention_in_days = 30
 tags = local.tags }

resource "aws_iam_role" "ecs_execution" {
  name = "${local.name}-ecs-execution"
  assume_role_policy = jsonencode({ Version = "2012-10-17", Statement = [{ Effect = "Allow", Principal = { Service = "ecs-tasks.amazonaws.com" }, Action = "sts:AssumeRole" }] })
  tags = local.tags
}
resource "aws_iam_role_policy_attachment" "ecs_execution" { role = aws_iam_role.ecs_execution.name
 policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy" }
resource "aws_iam_role_policy" "ecs_secrets" { role = aws_iam_role.ecs_execution.id
 policy = jsonencode({ Version = "2012-10-17", Statement = [{ Effect = "Allow", Action = ["secretsmanager:GetSecretValue"], Resource = aws_secretsmanager_secret.app.arn }] }) }
resource "aws_iam_role" "ecs_task" {
  name = "${local.name}-ecs-task"
  assume_role_policy = jsonencode({ Version = "2012-10-17", Statement = [{ Effect = "Allow", Principal = { Service = "ecs-tasks.amazonaws.com" }, Action = "sts:AssumeRole" }] })
  tags = local.tags
}
resource "aws_iam_role_policy" "ecs_task" {
  role = aws_iam_role.ecs_task.id
  policy = jsonencode({ Version = "2012-10-17", Statement = [
    { Effect = "Allow", Action = ["sqs:SendMessage", "sqs:GetQueueAttributes"], Resource = aws_sqs_queue.jobs.arn },
    { Effect = "Allow", Action = ["scheduler:CreateSchedule", "scheduler:UpdateSchedule", "scheduler:DeleteSchedule", "scheduler:GetSchedule"], Resource = "arn:aws:scheduler:${var.aws_region}:${data.aws_caller_identity.current.account_id}:schedule/${aws_scheduler_schedule_group.main.name}/*" },
    { Effect = "Allow", Action = ["iam:PassRole"], Resource = aws_iam_role.scheduler.arn, Condition = { StringEquals = { "iam:PassedToService" = "scheduler.amazonaws.com" } } },
    { Effect = "Allow", Action = ["s3:GetObject", "s3:PutObject", "s3:ListBucket"], Resource = [aws_s3_bucket.reports.arn, "${aws_s3_bucket.reports.arn}/*"] }
  ] })
}

resource "aws_ecs_cluster" "main" { name = local.name
 setting { name = "containerInsights"
 value = "enabled" }
 tags = local.tags }
resource "aws_lb" "main" { name = substr(local.name, 0, 32)
 internal = false
 load_balancer_type = "application"
 security_groups = [aws_security_group.alb.id]
 subnets = aws_subnet.public[*].id
 drop_invalid_header_fields = true
 tags = local.tags }
resource "aws_lb_target_group" "web" {
  name = substr("${local.name}-web", 0, 32)
  port = 8000
  protocol = "HTTP"
  vpc_id = aws_vpc.main.id
  target_type = "ip"
  deregistration_delay = 30
  health_check { path = "/health/ready/"
 matcher = "200"
 interval = 30
 timeout = 5
 healthy_threshold = 2
 unhealthy_threshold = 3 }
  tags = local.tags
}
resource "aws_lb_listener" "https" { load_balancer_arn = aws_lb.main.arn
 port = 443
 protocol = "HTTPS"
 ssl_policy = "ELBSecurityPolicy-TLS13-1-2-2021-06"
 certificate_arn = var.certificate_arn
 default_action { type = "forward"
 target_group_arn = aws_lb_target_group.web.arn } }

locals {
  common_env = [
    { name = "DJANGO_DEBUG", value = "false" },
    { name = "DJANGO_ALLOWED_HOSTS", value = aws_lb.main.dns_name },
    { name = "DJANGO_CSRF_TRUSTED_ORIGINS", value = "https://${aws_lb.main.dns_name}" },
    { name = "SECURE_SSL_REDIRECT", value = "true" },
    { name = "ENVIRONMENT", value = var.environment },
    { name = "AWS_REGION", value = var.aws_region },
    { name = "REPORT_QUEUE_BACKEND", value = "sqs" },
    { name = "REPORT_QUEUE_URL", value = aws_sqs_queue.jobs.url },
    { name = "REPORT_QUEUE_ARN", value = aws_sqs_queue.jobs.arn },
    { name = "REPORT_DLQ_ARN", value = aws_sqs_queue.dlq.arn },
    { name = "EVENTBRIDGE_SCHEDULER_ENABLED", value = "true" },
    { name = "EVENTBRIDGE_SCHEDULE_GROUP", value = aws_scheduler_schedule_group.main.name },
    { name = "EVENTBRIDGE_SCHEDULER_ROLE_ARN", value = aws_iam_role.scheduler.arn },
    { name = "RUN_MIGRATIONS", value = "false" }
  ]
  secrets = [for k in ["DJANGO_SECRET_KEY", "DATABASE_URL"] : { name = k, valueFrom = "${aws_secretsmanager_secret.app.arn}:${k}::" }]
}
resource "aws_ecs_task_definition" "web" {
  family = "${local.name}-web"
  requires_compatibilities = ["FARGATE"]
  network_mode = "awsvpc"
  cpu = 1024
  memory = 2048
  execution_role_arn = aws_iam_role.ecs_execution.arn
  task_role_arn = aws_iam_role.ecs_task.arn
  container_definitions = jsonencode([{ name = "web", image = var.web_container_image, essential = true, portMappings = [{ containerPort = 8000, protocol = "tcp" }], environment = local.common_env, secrets = local.secrets, healthCheck = { command = ["CMD-SHELL", "curl -f http://localhost:8000/health/ready/ || exit 1"], interval = 30, timeout = 5, retries = 3, startPeriod = 60 }, logConfiguration = { logDriver = "awslogs", options = { awslogs-group = aws_cloudwatch_log_group.ecs.name, awslogs-region = var.aws_region, awslogs-stream-prefix = "web" } } }])
  tags = local.tags
}
resource "aws_ecs_service" "web" {
  name = "web"
  cluster = aws_ecs_cluster.main.id
  task_definition = aws_ecs_task_definition.web.arn
  desired_count = var.desired_count
  launch_type = "FARGATE"
  enable_execute_command = true
  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent = 200
  availability_zone_rebalancing = "ENABLED"
  network_configuration { subnets = aws_subnet.private[*].id
 security_groups = [aws_security_group.app.id]
 assign_public_ip = false }
  load_balancer { target_group_arn = aws_lb_target_group.web.arn
 container_name = "web"
 container_port = 8000 }
  depends_on = [aws_lb_listener.https]
  tags = local.tags
}
resource "aws_appautoscaling_target" "web" { max_capacity = 4
 min_capacity = 2
 resource_id = "service/${aws_ecs_cluster.main.name}/${aws_ecs_service.web.name}"
 scalable_dimension = "ecs:service:DesiredCount"
 service_namespace = "ecs" }
resource "aws_appautoscaling_policy" "cpu" { name = "${local.name}-cpu"
 policy_type = "TargetTrackingScaling"
 resource_id = aws_appautoscaling_target.web.resource_id
 scalable_dimension = aws_appautoscaling_target.web.scalable_dimension
 service_namespace = aws_appautoscaling_target.web.service_namespace
 target_tracking_scaling_policy_configuration { target_value = 65
 predefined_metric_specification { predefined_metric_type = "ECSServiceAverageCPUUtilization" }
 scale_in_cooldown = 300
 scale_out_cooldown = 60 } }

resource "aws_iam_role" "lambda" {
  name = "${local.name}-lambda"
  assume_role_policy = jsonencode({ Version = "2012-10-17", Statement = [{ Effect = "Allow", Principal = { Service = "lambda.amazonaws.com" }, Action = "sts:AssumeRole" }] })
  tags = local.tags
}
resource "aws_iam_role_policy_attachment" "lambda_basic" { role = aws_iam_role.lambda.name
 policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole" }
resource "aws_iam_role_policy_attachment" "lambda_vpc" { role = aws_iam_role.lambda.name
 policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole" }
resource "aws_iam_role_policy" "lambda" {
  role = aws_iam_role.lambda.id
  policy = jsonencode({ Version = "2012-10-17", Statement = [
    { Effect = "Allow", Action = ["sqs:ReceiveMessage", "sqs:DeleteMessage", "sqs:GetQueueAttributes", "sqs:ChangeMessageVisibility"], Resource = aws_sqs_queue.jobs.arn },
    { Effect = "Allow", Action = ["secretsmanager:GetSecretValue"], Resource = aws_secretsmanager_secret.app.arn },
    { Effect = "Allow", Action = ["s3:GetObject", "s3:PutObject", "s3:ListBucket"], Resource = [aws_s3_bucket.reports.arn, "${aws_s3_bucket.reports.arn}/*"] }
  ] })
}
resource "aws_lambda_function" "worker" {
  function_name = "${local.name}-report-worker"
  package_type = "Image"
  image_uri = var.lambda_container_image
  role = aws_iam_role.lambda.arn
  timeout = var.lambda_timeout_seconds
  memory_size = var.lambda_memory_mb
  reserved_concurrent_executions = 10
  image_config { command = ["reports.lambda_handler.handler"] }
  environment { variables = { DJANGO_DEBUG = "false"
 DJANGO_SECRET_KEY = random_password.django.result
 DATABASE_URL = "postgresql://rcadmin:${random_password.db.result}@${aws_db_instance.main.address}:5432/rcadmin"
 AWS_REGION = var.aws_region
 REPORT_QUEUE_BACKEND = "sqs"
 REPORT_QUEUE_URL = aws_sqs_queue.jobs.url
 REPORT_QUEUE_ARN = aws_sqs_queue.jobs.arn
 REPORT_DLQ_ARN = aws_sqs_queue.dlq.arn
 EVENTBRIDGE_SCHEDULER_ENABLED = "false"
 AI_PROVIDER = "local"
 SECURE_SSL_REDIRECT = "false" } }
  vpc_config { subnet_ids = aws_subnet.private[*].id
 security_group_ids = [aws_security_group.lambda.id] }
  depends_on = [aws_cloudwatch_log_group.lambda, aws_iam_role_policy_attachment.lambda_basic, aws_iam_role_policy_attachment.lambda_vpc]
  tags = local.tags
}
resource "aws_lambda_event_source_mapping" "jobs" {
  event_source_arn = aws_sqs_queue.jobs.arn
  function_name = aws_lambda_function.worker.arn
  batch_size = 1
  enabled = true
  function_response_types = ["ReportBatchItemFailures"]
  scaling_config { maximum_concurrency = 10 }
}

resource "aws_cloudwatch_metric_alarm" "dlq" { alarm_name = "${local.name}-dlq-not-empty"
 comparison_operator = "GreaterThanThreshold"
 evaluation_periods = 1
 metric_name = "ApproximateNumberOfMessagesVisible"
 namespace = "AWS/SQS"
 period = 300
 statistic = "Maximum"
 threshold = 0
 treat_missing_data = "notBreaching"
 dimensions = { QueueName = aws_sqs_queue.dlq.name }
 tags = local.tags }
resource "aws_cloudwatch_metric_alarm" "lambda_errors" { alarm_name = "${local.name}-lambda-errors"
 comparison_operator = "GreaterThanThreshold"
 evaluation_periods = 1
 metric_name = "Errors"
 namespace = "AWS/Lambda"
 period = 300
 statistic = "Sum"
 threshold = 0
 treat_missing_data = "notBreaching"
 dimensions = { FunctionName = aws_lambda_function.worker.function_name }
 tags = local.tags }
resource "aws_cloudwatch_metric_alarm" "alb_5xx" { alarm_name = "${local.name}-alb-5xx"
 comparison_operator = "GreaterThanThreshold"
 evaluation_periods = 2
 metric_name = "HTTPCode_Target_5XX_Count"
 namespace = "AWS/ApplicationELB"
 period = 300
 statistic = "Sum"
 threshold = 5
 treat_missing_data = "notBreaching"
 dimensions = { LoadBalancer = aws_lb.main.arn_suffix }
 tags = local.tags }
