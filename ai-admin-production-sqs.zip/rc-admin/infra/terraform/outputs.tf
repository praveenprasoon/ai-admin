output "load_balancer_dns" { value = aws_lb.main.dns_name }
output "ecs_cluster_name" { value = aws_ecs_cluster.main.name }
output "ecs_service_name" { value = aws_ecs_service.web.name }
output "report_bucket" { value = aws_s3_bucket.reports.bucket }
output "report_queue_url" { value = aws_sqs_queue.jobs.url }
output "report_dlq_url" { value = aws_sqs_queue.dlq.url }
output "lambda_function_name" { value = aws_lambda_function.worker.function_name }
output "schedule_group_name" { value = aws_scheduler_schedule_group.main.name }
output "database_endpoint" {
  value     = aws_db_instance.main.address
  sensitive = true
}
