variable "project_name" {
  type    = string
  default = "rc-admin"
}
variable "environment" {
  type    = string
  default = "prod"
}
variable "aws_region" {
  type    = string
  default = "us-east-1"
}
variable "web_container_image" { type = string }
variable "lambda_container_image" { type = string }
variable "certificate_arn" { type = string }
variable "allowed_cidrs" {
  type    = list(string)
  default = ["0.0.0.0/0"]
}
variable "desired_count" {
  type    = number
  default = 2
}
variable "db_instance_class" {
  type    = string
  default = "db.t4g.small"
}
variable "db_multi_az" {
  type    = bool
  default = false
}
variable "lambda_memory_mb" {
  type    = number
  default = 2048
}
variable "lambda_timeout_seconds" {
  type    = number
  default = 900
}
