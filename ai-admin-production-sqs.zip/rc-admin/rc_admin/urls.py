from django.contrib import admin
from django.urls import include, path

from dashboard import views as health_views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include("reports.urls")),
    path("health/", health_views.health_live, name="health"),
    path("health/live/", health_views.health_live, name="health-live"),
    path("health/ready/", health_views.health_ready, name="health-ready"),
    path("", include("dashboard.urls")),
]
