from django.contrib import admin, messages

from .models import ProjectUpdate, ReportJob, ReportSchedule, WeeklyReport
from .scheduler import delete_schedule, sync_schedule


class ProjectUpdateInline(admin.TabularInline):
    model = ProjectUpdate
    extra = 0
    readonly_fields = ("project", "external_id", "source_type", "title", "status", "percent_complete", "summary", "risks", "blockers", "source_url")


@admin.register(WeeklyReport)
class WeeklyReportAdmin(admin.ModelAdmin):
    list_display = ("organization", "period_start", "period_end", "status", "updated_at")
    list_filter = ("status", "organization")
    inlines = [ProjectUpdateInline]


@admin.register(ReportJob)
class ReportJobAdmin(admin.ModelAdmin):
    list_display = ("id", "organization", "source", "status", "attempt_count", "created_at")
    list_filter = ("status", "source", "organization")
    readonly_fields = ("id", "attempt_count", "report", "error_message", "created_at", "updated_at")


@admin.register(ReportSchedule)
class ReportScheduleAdmin(admin.ModelAdmin):
    list_display = ("name", "organization", "enabled", "weekday", "hour", "minute", "timezone", "sync_status", "last_synced_at")
    list_filter = ("enabled", "sync_status", "organization")
    readonly_fields = ("aws_schedule_name", "aws_schedule_arn", "sync_status", "sync_error", "last_synced_at")
    actions = ("sync_selected",)

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        try:
            sync_schedule(obj)
            self.message_user(request, "Schedule synchronized.", messages.SUCCESS)
        except Exception as exc:
            self.message_user(request, f"Saved locally, but AWS synchronization failed: {exc}", messages.WARNING)

    def delete_model(self, request, obj):
        try:
            delete_schedule(obj)
        finally:
            super().delete_model(request, obj)

    @admin.action(description="Synchronize selected schedules")
    def sync_selected(self, request, queryset):
        succeeded = 0
        for schedule in queryset:
            try:
                sync_schedule(schedule)
                succeeded += 1
            except Exception:
                pass
        self.message_user(request, f"Synchronized {succeeded} of {queryset.count()} schedules.")
