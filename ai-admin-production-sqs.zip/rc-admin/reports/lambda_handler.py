import json
import os

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "rc_admin.settings")
django.setup()


def handler(event, context):
    from core.models import Organization

    from .worker import process_job

    failures = []
    for index, record in enumerate(event.get("Records", [])):
        try:
            payload = json.loads(record["body"])
            job_id = payload.get("job_id")
            if not job_id:
                organization = Organization.objects.get(
                    pk=payload["organization_id"], active=True
                )
                from .models import ReportJob

                job = ReportJob.objects.create(
                    organization=organization, source=payload.get("source", "SCHEDULED")
                )
                job_id = str(job.id)
            process_job(job_id)
        except Exception:
            failures.extend(
                {"itemIdentifier": item["messageId"]}
                for item in event["Records"][index:]
            )
            break
    return {"batchItemFailures": failures}
