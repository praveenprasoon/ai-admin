import json
import time

import boto3
from django.conf import settings
from django.core.management.base import BaseCommand

from reports.worker import process_job


class Command(BaseCommand):
    help = "Local/dev SQS FIFO consumer. Production uses Lambda."
    def handle(self, *args, **options):
        kwargs = {"region_name": settings.AWS_REGION}
        if settings.SQS_ENDPOINT_URL:
            kwargs["endpoint_url"] = settings.SQS_ENDPOINT_URL
        client = boto3.client("sqs", **kwargs)
        self.stdout.write("Waiting for report jobs...")
        while True:
            result = client.receive_message(QueueUrl=settings.REPORT_QUEUE_URL, MaxNumberOfMessages=1, WaitTimeSeconds=10, VisibilityTimeout=900)
            for message in result.get("Messages", []):
                try:
                    process_job(json.loads(message["Body"])["job_id"])
                    client.delete_message(QueueUrl=settings.REPORT_QUEUE_URL, ReceiptHandle=message["ReceiptHandle"])
                except Exception as exc:
                    self.stderr.write(str(exc))
            time.sleep(0.2)
