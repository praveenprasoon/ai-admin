import time

from django.core.management.base import BaseCommand
from django.utils import timezone

from reports.models import ReportSchedule
from reports.queueing import create_and_enqueue_job


class Command(BaseCommand):
    help = "Local-only EventBridge Scheduler emulator."
    def handle(self, *args, **options):
        seen = set()
        while True:
            now = timezone.localtime()
            key = now.strftime("%Y-%m-%d-%H-%M")
            if key not in seen:
                schedules = ReportSchedule.objects.filter(enabled=True, weekday=now.weekday(), hour=now.hour, minute=now.minute).select_related("organization")
                for schedule in schedules:
                    create_and_enqueue_job(schedule.organization, source="SCHEDULED")
                seen = {key}
            time.sleep(20)
