import uuid

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("reports", "0001_initial"), migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.AddField(model_name="reportschedule", name="minute", field=models.PositiveSmallIntegerField(default=0)),
        migrations.AddField(model_name="reportschedule", name="aws_schedule_name", field=models.CharField(blank=True, max_length=64)),
        migrations.AddField(model_name="reportschedule", name="aws_schedule_arn", field=models.CharField(blank=True, max_length=512)),
        migrations.AddField(model_name="reportschedule", name="sync_status", field=models.CharField(default="PENDING", max_length=20)),
        migrations.AddField(model_name="reportschedule", name="sync_error", field=models.TextField(blank=True)),
        migrations.AddField(model_name="reportschedule", name="last_synced_at", field=models.DateTimeField(blank=True, null=True)),
        migrations.CreateModel(
            name="ReportJob",
            fields=[
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("period_start", models.DateField(blank=True, null=True)),
                ("period_end", models.DateField(blank=True, null=True)),
                ("status", models.CharField(choices=[("QUEUED", "Queued"), ("RUNNING", "Running"), ("COMPLETED", "Completed"), ("FAILED", "Failed")], default="QUEUED", max_length=20)),
                ("source", models.CharField(default="MANUAL", max_length=20)),
                ("attempt_count", models.PositiveSmallIntegerField(default=0)),
                ("error_message", models.TextField(blank=True)),
                ("organization", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="report_jobs", to="core.organization")),
                ("report", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="jobs", to="reports.weeklyreport")),
                ("requested_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-created_at"]},
        ),
    ]
