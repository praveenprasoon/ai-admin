import uuid

from django.conf import settings
from django.db import models

from core.models import Organization, Project, TimeStampedModel


class ReportSchedule(TimeStampedModel):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name="report_schedules")
    name = models.CharField(max_length=255, default="Weekly Executive Report")
    enabled = models.BooleanField(default=True)
    weekday = models.PositiveSmallIntegerField(default=4, help_text="Monday=0, Friday=4")
    hour = models.PositiveSmallIntegerField(default=9)
    minute = models.PositiveSmallIntegerField(default=0)
    timezone = models.CharField(max_length=100, default="America/New_York")
    recipients = models.JSONField(default=list, blank=True)
    aws_schedule_name = models.CharField(max_length=64, blank=True)
    aws_schedule_arn = models.CharField(max_length=512, blank=True)
    sync_status = models.CharField(max_length=20, default="PENDING")
    sync_error = models.TextField(blank=True)
    last_synced_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.organization}: {self.name}"

    @property
    def cron_expression(self):
        # EventBridge uses SUN=1 ... SAT=7; Django stores Monday=0 ... Sunday=6.
        aws_day = ((self.weekday + 1) % 7) + 1
        return f"cron({self.minute} {self.hour} ? * {aws_day} *)"


class ReportJob(TimeStampedModel):
    STATUS_CHOICES = [
        ("QUEUED", "Queued"), ("RUNNING", "Running"),
        ("COMPLETED", "Completed"), ("FAILED", "Failed"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name="report_jobs")
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    period_start = models.DateField(null=True, blank=True)
    period_end = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="QUEUED")
    source = models.CharField(max_length=20, default="MANUAL")
    attempt_count = models.PositiveSmallIntegerField(default=0)
    report = models.ForeignKey("WeeklyReport", null=True, blank=True, on_delete=models.SET_NULL, related_name="jobs")
    error_message = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]


class WeeklyReport(TimeStampedModel):
    STATUS_CHOICES = [("RUNNING", "Running"), ("COMPLETED", "Completed"), ("FAILED", "Failed")]
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name="weekly_reports")
    period_start = models.DateField()
    period_end = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="RUNNING")
    executive_summary = models.TextField(blank=True)
    metrics = models.JSONField(default=dict)
    warnings = models.JSONField(default=list)
    error_message = models.TextField(blank=True)

    class Meta:
        unique_together = ("organization", "period_start", "period_end")
        ordering = ["-period_end", "-created_at"]


class ProjectUpdate(TimeStampedModel):
    report = models.ForeignKey(WeeklyReport, on_delete=models.CASCADE, related_name="project_updates")
    project = models.ForeignKey(Project, on_delete=models.SET_NULL, null=True, blank=True)
    external_id = models.CharField(max_length=255)
    source_type = models.CharField(max_length=50)
    title = models.CharField(max_length=500)
    status = models.CharField(max_length=20, default="UNKNOWN")
    percent_complete = models.PositiveSmallIntegerField(default=0)
    summary = models.TextField(blank=True)
    risks = models.JSONField(default=list)
    blockers = models.JSONField(default=list)
    source_url = models.URLField(blank=True)
    source_updated_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["status", "project__key", "external_id"]
