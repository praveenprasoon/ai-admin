import hashlib
import json
import logging
from datetime import date

import boto3
from django.conf import settings
from django.db import transaction

from .models import ReportJob

logger = logging.getLogger(__name__)


def _client():
    kwargs = {"region_name": settings.AWS_REGION}
    if settings.SQS_ENDPOINT_URL:
        kwargs["endpoint_url"] = settings.SQS_ENDPOINT_URL
    return boto3.client("sqs", **kwargs)


def _dedupe(job):
    raw = f"{job.organization_id}:{job.period_start}:{job.period_end}:{job.id}"
    return hashlib.sha256(raw.encode()).hexdigest()


def enqueue_report_job(job: ReportJob):
    body = json.dumps({
        "schema_version": 1,
        "job_id": str(job.id),
        "organization_id": job.organization_id,
        "period_start": job.period_start.isoformat() if job.period_start else None,
        "period_end": job.period_end.isoformat() if job.period_end else None,
        "source": job.source,
    })
    if settings.REPORT_QUEUE_BACKEND == "inline":
        from .worker import process_job
        process_job(str(job.id))
        return {"MessageId": f"inline-{job.id}"}
    return _client().send_message(
        QueueUrl=settings.REPORT_QUEUE_URL,
        MessageBody=body,
        MessageGroupId=f"organization-{job.organization_id}",
        MessageDeduplicationId=_dedupe(job),
    )


def create_and_enqueue_job(organization, requested_by=None, period_start: date | None = None,
                           period_end: date | None = None, source="MANUAL"):
    with transaction.atomic():
        job = ReportJob.objects.create(
            organization=organization, requested_by=requested_by,
            period_start=period_start, period_end=period_end, source=source,
        )
        transaction.on_commit(lambda: enqueue_report_job(job))
    return job
