import json
import logging
import re

import boto3
from django.conf import settings
from django.utils import timezone

logger = logging.getLogger(__name__)


def _client():
    kwargs = {"region_name": settings.AWS_REGION}
    if settings.SCHEDULER_ENDPOINT_URL:
        kwargs["endpoint_url"] = settings.SCHEDULER_ENDPOINT_URL
    return boto3.client("scheduler", **kwargs)


def _name(schedule):
    base = re.sub(r"[^A-Za-z0-9-_]", "-", f"rc-admin-{schedule.organization_id}-{schedule.pk}")
    return base[:64]


def sync_schedule(schedule):
    if not settings.EVENTBRIDGE_SCHEDULER_ENABLED:
        schedule.sync_status = "LOCAL"
        schedule.sync_error = "EventBridge synchronization disabled in this environment."
        schedule.last_synced_at = timezone.now()
        schedule.save(update_fields=["sync_status", "sync_error", "last_synced_at", "updated_at"])
        return
    name = schedule.aws_schedule_name or _name(schedule)
    payload = json.dumps({"schema_version": 1, "organization_id": schedule.organization_id, "source": "SCHEDULED"})
    kwargs = {
        "Name": name,
        "GroupName": settings.EVENTBRIDGE_SCHEDULE_GROUP,
        "ScheduleExpression": schedule.cron_expression,
        "ScheduleExpressionTimezone": schedule.timezone,
        "FlexibleTimeWindow": {"Mode": "OFF"},
        "State": "ENABLED" if schedule.enabled else "DISABLED",
        "Target": {
            "Arn": settings.REPORT_QUEUE_ARN,
            "RoleArn": settings.EVENTBRIDGE_SCHEDULER_ROLE_ARN,
            "Input": payload,
            "SqsParameters": {"MessageGroupId": f"organization-{schedule.organization_id}"},
            "RetryPolicy": {"MaximumEventAgeInSeconds": 3600, "MaximumRetryAttempts": 3},
            "DeadLetterConfig": {"Arn": settings.REPORT_DLQ_ARN},
        },
        "Description": f"RC Admin schedule {schedule.pk}: {schedule.name}",
    }
    client = _client()
    try:
        try:
            result = client.update_schedule(**kwargs)
        except client.exceptions.ResourceNotFoundException:
            result = client.create_schedule(**kwargs)
        schedule.aws_schedule_name = name
        schedule.aws_schedule_arn = result.get("ScheduleArn", schedule.aws_schedule_arn)
        schedule.sync_status = "SYNCED"
        schedule.sync_error = ""
        schedule.last_synced_at = timezone.now()
    except Exception as exc:
        schedule.sync_status = "ERROR"
        schedule.sync_error = str(exc)[:4000]
        logger.exception("Schedule synchronization failed", extra={"schedule_id": schedule.pk})
        raise
    finally:
        schedule.save(update_fields=["aws_schedule_name", "aws_schedule_arn", "sync_status", "sync_error", "last_synced_at", "updated_at"])


def delete_schedule(schedule):
    if settings.EVENTBRIDGE_SCHEDULER_ENABLED and schedule.aws_schedule_name:
        _client().delete_schedule(Name=schedule.aws_schedule_name, GroupName=settings.EVENTBRIDGE_SCHEDULE_GROUP)
