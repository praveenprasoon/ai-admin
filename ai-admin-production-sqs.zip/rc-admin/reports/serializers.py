from rest_framework import serializers

from .models import ProjectUpdate, WeeklyReport


class ProjectUpdateSerializer(serializers.ModelSerializer):
    project_key = serializers.CharField(source="project.key", allow_null=True, read_only=True)
    project_name = serializers.CharField(source="project.name", allow_null=True, read_only=True)

    class Meta:
        model = ProjectUpdate
        fields = [
            "id", "project_key", "project_name", "external_id", "source_type",
            "title", "status", "percent_complete", "summary", "risks",
            "blockers", "source_url", "source_updated_at",
        ]

class WeeklyReportSerializer(serializers.ModelSerializer):
    project_updates = ProjectUpdateSerializer(many=True, read_only=True)

    class Meta:
        model = WeeklyReport
        fields = [
            "id", "organization", "period_start", "period_end", "status",
            "executive_summary", "metrics", "warnings", "project_updates",
            "created_at", "updated_at",
        ]
