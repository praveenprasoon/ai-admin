from datetime import datetime, time, timedelta

from dateutil.parser import isoparse
from django.db import transaction
from django.utils import timezone

from agent.services import NarrativeInput, get_narrative_provider
from connectors.models import DataSource
from connectors.services import run_data_source

from .models import ProjectUpdate, WeeklyReport

VALID_STATUSES = {"ON_TRACK", "AT_RISK", "OFF_TRACK", "UNKNOWN"}

def _to_aware_datetime(value):
    if not value:
        return None
    if isinstance(value, datetime):
        parsed = value
    else:
        parsed = isoparse(value)
    if timezone.is_naive(parsed):
        parsed = timezone.make_aware(parsed)
    return parsed

def _normalize_record(record, data_source):
    status = str(record.get("status", "UNKNOWN")).upper()
    if status not in VALID_STATUSES:
        status = "UNKNOWN"
    percent = max(0, min(100, int(record.get("percent_complete", 0) or 0)))
    return {
        "project": data_source.project,
        "external_id": str(record.get("external_id", "unknown")),
        "source_type": data_source.source_type,
        "title": str(record.get("title", "Untitled update"))[:500],
        "status": status,
        "percent_complete": percent,
        "summary": str(record.get("summary", "")),
        "risks": list(record.get("risks", []) or []),
        "blockers": list(record.get("blockers", []) or []),
        "source_url": str(record.get("source_url", "")),
        "source_updated_at": _to_aware_datetime(record.get("updated_at")),
    }

def calculate_metrics(updates):
    statuses = [u["status"] for u in updates]
    return {
        "total_projects": len({u["project"].id for u in updates if u["project"]}),
        "total_updates": len(updates),
        "on_track": statuses.count("ON_TRACK"),
        "at_risk": statuses.count("AT_RISK"),
        "off_track": statuses.count("OFF_TRACK"),
        "unknown": statuses.count("UNKNOWN"),
        "average_percent_complete": (
            round(sum(u["percent_complete"] for u in updates) / len(updates), 1)
            if updates else 0
        ),
    }

@transaction.atomic
def generate_weekly_report(organization, period_start=None, period_end=None):
    today = timezone.localdate()
    period_end = period_end or today
    period_start = period_start or (period_end - timedelta(days=6))

    report, _ = WeeklyReport.objects.get_or_create(
        organization=organization,
        period_start=period_start,
        period_end=period_end,
        defaults={"status": "RUNNING"},
    )
    report.status = "RUNNING"
    report.error_message = ""
    report.save(update_fields=["status", "error_message", "updated_at"])
    report.project_updates.all().delete()

    start_at = timezone.make_aware(datetime.combine(period_start, time.min))
    end_at = timezone.make_aware(datetime.combine(period_end, time.max))

    normalized = []
    warnings = []

    sources = DataSource.objects.filter(
        organization=organization,
        enabled=True,
    ).select_related("project", "organization")

    for source in sources:
        try:
            result = run_data_source(source, start_at, end_at)
            warnings.extend([f"{source.name}: {warning}" for warning in result.warnings])
            normalized.extend(_normalize_record(record, source) for record in result.records)
        except Exception as exc:
            warnings.append(f"{source.name}: connector failed: {exc}")

    for item in normalized:
        ProjectUpdate.objects.create(report=report, **item)

    metrics = calculate_metrics(normalized)
    narrative = get_narrative_provider().generate(
        NarrativeInput(
            organization_name=organization.name,
            period_label=f"{period_start.isoformat()} through {period_end.isoformat()}",
            metrics=metrics,
            updates=normalized,
            warnings=warnings,
        )
    )

    report.status = "COMPLETED"
    report.metrics = metrics
    report.warnings = warnings
    report.executive_summary = narrative
    report.save()
    return report
