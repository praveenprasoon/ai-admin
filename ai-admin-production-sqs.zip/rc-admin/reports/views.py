from django.shortcuts import get_object_or_404
from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied
from rest_framework.response import Response

from core.models import Organization
from core.permissions import accessible_organization_ids, can_manage_organization

from .models import WeeklyReport
from .queueing import create_and_enqueue_job
from .serializers import WeeklyReportSerializer


class WeeklyReportViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = WeeklyReportSerializer
    permission_classes = [permissions.IsAuthenticated]
    filterset_fields = ["organization", "status", "period_start", "period_end"]

    def get_queryset(self):
        qs = WeeklyReport.objects.select_related("organization").prefetch_related("project_updates__project")
        ids = accessible_organization_ids(self.request.user)
        return qs if ids is None else qs.filter(organization_id__in=ids)

    @action(detail=False, methods=["post"])
    def generate(self, request):
        organization = get_object_or_404(Organization, pk=request.data.get("organization_id"), active=True)
        if not can_manage_organization(request.user, organization.id):
            raise PermissionDenied("PMO or administrator access is required.")
        job = create_and_enqueue_job(organization, requested_by=request.user)
        return Response({"job_id": str(job.id), "status": job.status}, status=status.HTTP_202_ACCEPTED)
