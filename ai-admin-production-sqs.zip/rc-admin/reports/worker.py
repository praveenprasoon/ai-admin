import logging

from django.db import transaction

from .models import ReportJob
from .services import generate_weekly_report

logger = logging.getLogger(__name__)


def process_job(job_id: str):
    with transaction.atomic():
        job = ReportJob.objects.select_for_update().select_related("organization").get(pk=job_id)
        if job.status == "COMPLETED":
            return job
        job.status = "RUNNING"
        job.attempt_count += 1
        job.error_message = ""
        job.save(update_fields=["status", "attempt_count", "error_message", "updated_at"])
    try:
        report = generate_weekly_report(job.organization, job.period_start, job.period_end)
        job.status = "COMPLETED"
        job.report = report
        job.error_message = ""
        job.save(update_fields=["status", "report", "error_message", "updated_at"])
    except Exception as exc:
        logger.exception("Report job failed", extra={"job_id": job_id})
        job.status = "FAILED"
        job.error_message = str(exc)[:4000]
        job.save(update_fields=["status", "error_message", "updated_at"])
        raise
    return job
