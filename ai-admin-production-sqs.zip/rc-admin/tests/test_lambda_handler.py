import json
from unittest.mock import patch

import pytest

from core.models import Organization
from reports.lambda_handler import handler
from reports.models import ReportJob


@pytest.mark.django_db
def test_scheduled_message_creates_and_processes_job():
    organization = Organization.objects.create(name="Leadership", slug="leadership")
    event = {
        "Records": [
            {
                "messageId": "m1",
                "body": json.dumps(
                    {"organization_id": organization.id, "source": "SCHEDULED"}
                ),
            }
        ]
    }
    with patch("reports.worker.generate_weekly_report") as generate:
        generate.return_value.id = 1
        # Avoid assigning a non-model mock as FK by making process_job the unit boundary.
        with patch("reports.worker.process_job"):
            result = handler(event, None)
    assert result == {"batchItemFailures": []}
    assert ReportJob.objects.filter(organization=organization, source="SCHEDULED").exists()
