import pytest
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient

from core.models import Organization, OrganizationMembership
from reports.models import WeeklyReport


@pytest.mark.django_db
def test_user_only_sees_member_organizations():
    user = get_user_model().objects.create_user(username="viewer", password="secure-test-password")
    allowed = Organization.objects.create(name="Allowed", slug="allowed")
    denied = Organization.objects.create(name="Denied", slug="denied")
    OrganizationMembership.objects.create(user=user, organization=allowed, role="VIEWER")
    WeeklyReport.objects.create(organization=allowed, period_start="2026-07-01", period_end="2026-07-07")
    WeeklyReport.objects.create(organization=denied, period_start="2026-07-01", period_end="2026-07-07")
    client = APIClient()
    client.force_authenticate(user=user)
    response = client.get("/api/reports/")
    assert response.status_code == 200
    assert response.data["count"] == 1
    assert response.data["results"][0]["organization"] == allowed.id

@pytest.mark.django_db
def test_viewer_cannot_generate_report():
    user = get_user_model().objects.create_user(username="viewer", password="secure-test-password")
    org = Organization.objects.create(name="Org", slug="org")
    OrganizationMembership.objects.create(user=user, organization=org, role="VIEWER")
    client = APIClient()
    client.force_authenticate(user=user)
    response = client.post("/api/reports/generate/", {"organization_id": org.id}, format="json")
    assert response.status_code == 403
