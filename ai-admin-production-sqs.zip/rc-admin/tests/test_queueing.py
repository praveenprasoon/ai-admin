from unittest.mock import patch

import pytest
from django.contrib.auth.models import User

from core.models import Organization
from reports.models import ReportJob
from reports.queueing import create_and_enqueue_job


@pytest.mark.django_db
def test_manual_job_is_created_and_enqueued(settings, django_capture_on_commit_callbacks):
    settings.REPORT_QUEUE_BACKEND = "sqs"
    org = Organization.objects.create(name="Executive Portfolio", slug="executive")
    user = User.objects.create_user("director")
    with patch("reports.queueing.enqueue_report_job") as enqueue:
        with django_capture_on_commit_callbacks(execute=True):
            job = create_and_enqueue_job(org, requested_by=user)
    assert job.status == "QUEUED"
    assert ReportJob.objects.filter(pk=job.pk).exists()
    enqueue.assert_called_once()
