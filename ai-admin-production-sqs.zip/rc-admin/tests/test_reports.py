import pytest

from connectors.models import DataSource
from core.models import Organization, Portfolio, Project
from reports.services import generate_weekly_report


@pytest.mark.django_db
def test_generates_report_from_registered_connector():
    org = Organization.objects.create(name="Test Org", slug="test-org")
    portfolio = Portfolio.objects.create(organization=org, name="Portfolio", key="PF")
    project = Project.objects.create(portfolio=portfolio, name="Project", key="PRJ")
    DataSource.objects.create(
        organization=org,
        project=project,
        name="Demo",
        source_type="mock",
        configuration={"project_key": "PRJ", "status": "AT_RISK", "percent_complete": 50},
    )

    report = generate_weekly_report(org)

    assert report.status == "COMPLETED"
    assert report.metrics["at_risk"] == 1
    assert report.project_updates.count() == 1
    assert "Test Org" in report.executive_summary
